# Fetch-Country-List-using-beautifulsoup4
Here's a small script that will allow you to fetch Countries for your Django E-commerce Website.
