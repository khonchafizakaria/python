# reference_id_generator
a function that helps generate a 19 length character id for your Clients, Products, Orders, ...
You need:

  ++ random module
  
  ++ string module (or you can do this the lazy way by using list(azerty...AZERTY...123...890))
